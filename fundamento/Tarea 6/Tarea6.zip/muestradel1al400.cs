using System;

class program{
	public static void Main(string[] args){
		Console.Clear();
		Console.WriteLine("Programa que muestra los numeros del 1 al 400");
		int x = 0;
		
		while(x<400){
			 
			x= x+1;
			Console.WriteLine(x);
		} Console.ReadLine();
		
		
		
		
	}
	
	
}