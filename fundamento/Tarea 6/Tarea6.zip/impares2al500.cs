using System;

class program{
	public static void Main(string[] args){
		Console.Clear();
		Console.WriteLine("Programa que muestra los numeros impares del 2 al 500");
		int x = 2;
		int z = 0;
		int y = 2;
		int k = 500;
		Console.WriteLine(y);
		while(x<500){ 

			x = x+2;
			z = x-1;
			Console.WriteLine(z);
		
		} 
		Console.WriteLine(k);
		Console.ReadLine();
		
		
		
		
	}
	
	
}