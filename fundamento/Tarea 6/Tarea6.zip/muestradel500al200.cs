using System;

class program{
	public static void Main(string[] args){
		Console.Clear();
		Console.WriteLine("Programa que muestra los numeros del 500 al 200");
		int x = 501;
		
		while(x>200){
			 
			x= x-1;
			Console.WriteLine(x);
		} Console.ReadLine();
		
		
		
		
	}
	
	
}