using System;

class program{
	public static void Main(string[] args){
		Console.Clear();
		Console.WriteLine("Programa que muestra los multiplos del 7, hasta el 100");
		int x = 0;
		
		while(x<98){
			
			x= x+7;
			
			Console.WriteLine(x);
		} Console.ReadLine();
		
		
		
		
	}
	
	
}