using System;

	class frasefacil{
			
		public static void Main (){
			string frase = "";
				
			Console.Clear();
			Console.WriteLine("programa que te dice cuantos caracteres tiene una frase");
			Console.Write("Digita la frase: ");
			frase = Console.ReadLine();
			Console.WriteLine("La frase tiene {0} caracteres",frase.Length);
			Console.ReadLine();
		}
	
		
		
		
		
		
		
		
	}